# Launch GoldenTongue without a terminal (Supabase + Cloudflare + GitHub)

Everything is done in web dashboards. About 45 minutes. Nothing here is tested against your real accounts yet.

## A. Supabase (database and sign-in)
1. supabase.com > New project. Note the **Project URL**, the **anon key** and the **project id** (Settings > API).
2. SQL Editor > New query. Paste `supabase/bundle/1_schema.sql`, Run. Then paste `2_content_lines.sql`, Run, then `3_content_more.sql`, Run. Each must end with "Success". Order matters.
3. Authentication > Providers > Email: on, "Confirm email" on. Authentication > URL Configuration: Site URL = your website address; add it to Redirect URLs.
4. Storage: check that a bucket named `voice` exists and is **private** (the schema creates it).
5. Edge Functions > Secrets: add `OPENAI_API_KEY`, `APP_URL` (your website address), `STRIPE_SECRET_KEY`, `STRIPE_WEBHOOK_SECRET`, `STRIPE_PRICE_MONTHLY`, `STRIPE_PRICE_QUARTERLY`, `STRIPE_PRICE_YEARLY`.
6. Account > Access Tokens: create one (for step C).

## B. Cloudflare (website)
1. Workers & Pages > Create > Pages > **Connect to Git**, choose the repo. Settings: root directory `cloudflare/members-site`, build command empty, output directory `public`. Cloudflare builds the `functions/` folder (the member gate) automatically from Git.
2. Settings > Variables and Secrets (Production): `SUPABASE_URL`, `SUPABASE_ANON_KEY`, `OPENAI_API_KEY` (secret), optional `TURNSTILE_SITE_KEY`, `PRIVACY_URL`, `TERMS_URL`, `SUPPORT_EMAIL`. Keep `REQUIRE_PREMIUM=true`.
3. Custom domains > add your domain.
4. Profile > API Tokens > create a token with "Cloudflare Pages: Edit" (for step C). Copy your Account ID.

## C. GitHub (deploys the AI functions)
1. Push this project to a private GitHub repo.
2. Settings > Secrets and variables > Actions: add `SUPABASE_ACCESS_TOKEN`, `SUPABASE_PROJECT_REF`, `CLOUDFLARE_API_TOKEN`, `CLOUDFLARE_ACCOUNT_ID`; variable `PAGES_PROJECT`.
3. Actions > deploy-members > Run workflow. It deploys the AI functions to Supabase and tests and publishes the site.

## D. Stripe and admin
1. Stripe: three recurring prices (14.99 / 34.99 / 99.99, no trial). Webhook endpoint `https://<ref>.supabase.co/functions/v1/stripe-webhook`, events `customer.subscription.created`, `customer.subscription.updated`, `customer.subscription.deleted`. Put the signing secret into the Supabase secrets (A5).
2. Create your account on the site, then in Supabase SQL Editor run: `select public.grant_admin('you@example.com');`

## E. Check
Logged out -> login. New account, unpaid -> membership page. Test payment -> app opens. Admin -> app opens without paying.
Finish `docs/legal/` first (see `scripts/check_legal.sh`).
