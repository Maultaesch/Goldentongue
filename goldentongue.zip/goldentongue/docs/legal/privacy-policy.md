# GoldenTongue Privacy Policy

> **DRAFT. Not legal advice.** Replace every `[[PLACEHOLDER]]`, have a lawyer review it, then publish it at the address you set as `PRIVACY_URL`. The launch check stops while any `[[...]]` is left in this file.

Last updated: [[DATE]]

## 1. Who is responsible
[[COMPANY_NAME]], [[ADDRESS]] ("we", "GoldenTongue"). Contact for privacy questions: [[PRIVACY_EMAIL]]. [[If required: data protection officer contact]]

## 2. What we collect and why
| Data | Why | Legal basis (GDPR) |
|---|---|---|
| Email address, password (stored only as a hash by our sign-in provider), account id | Create and secure your account | Contract (Art. 6(1)(b)) |
| Membership status, plan, renewal date, payment provider customer id | Give members access and handle renewals | Contract |
| Your messages to the AI coach, simulator and exercises, and the AI replies | Provide the feature you asked for | Contract |
| Voice recordings (Voice Attraction Analyzer only) | Analyze your speech. See section 4 | Consent (Art. 6(1)(a)), which you give by pressing record |
| Scores, XP, streaks, favourites, progress, Charm Blueprint answers | Show your progress and personalize training | Contract |
| Usage counters (AI requests per day) | Fair-use limits and abuse protection | Legitimate interest (Art. 6(1)(f)) |
| Technical data such as IP address and browser type, held briefly in server logs | Security, bot protection, fixing errors | Legitimate interest |

We do not sell your data and we do not use it for advertising.

## 3. Payments
Card and wallet payments are handled by **Stripe** (website) and by **Apple App Store / Google Play** through **RevenueCat** (mobile apps). We never see or store your full card number. We receive your plan, payment status and a customer id.

## 4. Voice recordings
When you record a voice sample, the audio is uploaded to a private storage area that only your account can reach and is sent to our AI service for analysis. The recording is deleted after the analysis finishes. [[CONFIRM before launch: recordings left behind by a failed analysis are also removed within [[HOURS]] hours. Check the cleanup job.]] We keep the resulting scores and feedback text, not the audio. We do not use voice recordings to identify you.

## 5. AI processing
Your coaching text and, for the analyzer, your recording are sent to **OpenAI** to generate replies and feedback. [[Check OpenAI's current data-processing terms and state here whether API data is used for training (by default it is not) and which retention applies.]] Do not enter information you would not want processed this way, such as health or financial details of other people.

## 6. Service providers (processors)
| Provider | Purpose | Location |
|---|---|---|
| Supabase | Database, sign-in, file storage, server functions | [[REGION]] |
| Cloudflare | Website hosting, security, bot protection (Turnstile) | Global network |
| OpenAI | AI replies and voice analysis | [[USA / region]] |
| Stripe | Web payments | [[region]] |
| RevenueCat, Apple, Google | Mobile subscriptions | [[region]] |

Where data leaves the EU/EEA we rely on [[Standard Contractual Clauses / adequacy decision]].

## 7. Cookies and similar storage
We use only what is needed to run the site:
- `gt_at` and `gt_rt`: sign-in cookies (HttpOnly, Secure, SameSite=Lax). They keep you logged in and are deleted when you log out or they expire.
- Cloudflare Turnstile may set technical data to tell humans from bots.
- The mobile app and website store settings such as your last tab on your device.

We use no advertising or tracking cookies. [[Add a consent banner here if you later add analytics.]]

## 8. How long we keep data
Account and progress data: until you delete your account. Payment records: as long as tax law requires ([[YEARS]] years). Server logs: up to [[DAYS]] days.

## 9. Your rights
You can ask for access, correction, deletion, restriction, export, and you can object to processing based on legitimate interest or withdraw consent at any time. You can delete your account yourself in the app (Profile) or on the website's delete-account page, which removes your data. You can also write to [[PRIVACY_EMAIL]]. You may complain to your data protection authority: [[AUTHORITY]].

## 10. Age
GoldenTongue is for people aged **18 and over**. We do not knowingly collect data from anyone younger. If you think a minor has an account, contact us and we will delete it.

## 11. Security
Traffic is encrypted. Access to member content is checked in the database itself, and recordings are private to your account. No system is perfectly secure; we will notify you and the authorities of a breach where the law requires.

## 12. Changes
We will post changes here and, for material changes, tell you in the app or by email before they apply.
