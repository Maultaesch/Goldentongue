# GoldenTongue Terms of Use

> **DRAFT. Not legal advice.** Replace every `[[PLACEHOLDER]]`, have a lawyer review it, then publish it at the address you set as `TERMS_URL`. The launch check stops while any `[[...]]` is left in this file.

Last updated: [[DATE]]

## 1. Who we are and what this covers
These terms apply between you and [[COMPANY_NAME]], [[ADDRESS]] ("GoldenTongue") for the GoldenTongue website and mobile apps. By creating an account you accept them and our Privacy Policy. You must be **18 or older**.

## 2. Account
You need an account to use GoldenTongue. Give a correct email address, keep your password secret and tell us if you think someone else has access. You are responsible for activity under your account.

## 3. Membership and payment
- Access to GoldenTongue content and features requires a paid membership. There is no free tier and **no free trial**.
- Plans: monthly USD 14.99, quarterly USD 34.99, yearly USD 99.99 [[plus applicable taxes; confirm final prices and currencies]].
- **Automatic renewal.** Your membership renews at the end of each period at the then-current price until you cancel. Cancel any time; access continues to the end of the paid period.
- Web purchases are billed by Stripe. Store purchases are billed by Apple or Google and are managed and cancelled in your store account.
- Refunds: [[REFUND_POLICY, e.g. statutory withdrawal right for EU consumers and how it ends when digital content starts]]. Store purchases follow the store's refund rules.
- If a payment fails or is reversed, we may suspend access until it is resolved.
- We may change prices for future periods with at least [[DAYS]] days' notice. You can cancel before the change applies.

## 4. What GoldenTongue is
GoldenTongue is a communication and confidence training tool. Content, scores and AI feedback are for practice and education. They are **not** professional advice (psychological, medical, legal or financial) and we do not promise any result, such as replies, dates, deals or jobs.

## 5. AI features and fair use
- AI replies can be wrong, awkward or unsuitable. Use your own judgment before you act on them.
- Members get a daily allowance (currently up to [[300]] AI requests, [[20]] voice analyses and [[20]] practice answers per day). We may change these limits to keep the service stable and affordable. Excessive or automated use can be limited.
- You may not use scripts, bots or resale to extract content or AI output at scale.

## 6. Voice analysis and consent
By recording your voice you consent to its upload and AI analysis as described in the Privacy Policy. Only record your own voice or voices of people who agreed.

## 7. Acceptable use
Use GoldenTongue to communicate respectfully and honestly. You may not:
- use it to harass, stalk, pressure, deceive or manipulate anyone, or to ignore a "no";
- generate content that is unlawful, hateful, sexually explicit involving minors, or threatening;
- share your account, resell access or copy the content library;
- probe, overload or bypass the security, limits or payment checks of the service.

We may suspend or end accounts that break these rules, with refund treatment as in section 3 [[adjust]].

## 8. Our content and your content
We and our licensors own the content library (lines, openers, techniques, exercises, design). We give you a personal, non-transferable licence to use it while you are a member. You keep rights to what you write and record. You give us the right to process it to run the service, as described in the Privacy Policy.

## 9. Availability
We aim for reliable service but do not guarantee uninterrupted access. We may change or retire features. If we remove a paid feature in a material way, [[remedy]].

## 10. Liability
Nothing here limits liability that cannot be limited by law (for example for intent, injury to life, body or health, or mandatory consumer rights). Otherwise, [[LIABILITY_CLAUSE, to be drafted by your lawyer for your country]].

## 11. Ending your account
You can delete your account in the app or on the website at any time. Deletion removes your data as described in the Privacy Policy and ends your membership; unused paid time is not refunded unless the law or section 3 says so.

## 12. Changes
We may update these terms. We will tell you of material changes in advance. If you keep using GoldenTongue after they apply, you accept them; if not, you can cancel.

## 13. Governing law and contact
[[GOVERNING_LAW and court, respecting mandatory consumer protections in your country of residence]]. Questions: [[SUPPORT_EMAIL]].
