# Launch the GoldenTongue website with the AI service

This is the shortest safe path from "files on my computer" to "members can log in, pay and use the AI".
You do it from your own computer (nobody else can log in to your accounts). Plan about 60 to 90 minutes the first time.

## What you are launching
```
Members' browser -> Cloudflare Pages  (login, paywall, the app; AI endpoint /api/ai)
                       |  checks the member on every request
                       v
                    Supabase (accounts, database, payment status, edge functions)
                       |  AI calls
                       v
                    OpenAI (the AI service)      Stripe (payments, optional at first)
```
Access rules: no account, no entry. Account without membership: only the payment page. Paying members: everything, with a
fair-use cap on AI calls. Admin (you): everything, no payment, no limits.

## 0. Accounts you need (create them first)
| Service | What to do | Cost note |
|---|---|---|
| Supabase | New project, region near your members, strong database password (save it). | free plan works to start |
| OpenAI (platform.openai.com) | Add a payment method, create an API key just for GoldenTongue, **set a monthly spend limit** (Settings, Limits). | pay per use |
| Cloudflare | Free account, no domain needed yet. | free |
| Stripe | Optional now. Without it only admins get in (good for a private test). Use test mode first. | fees per payment |

## 1. Install the tools (once)
Node 22 or newer, the Supabase CLI, and `psql` (PostgreSQL client). Then:
```
supabase login
npx wrangler login
```
Both open your browser: you log in on their websites yourself.

## 2. Fill in your settings
```
cp launch/.env.example launch/.env
```
Open `launch/.env` and fill it in. Where to find each value is written next to it. Never share this file or commit it
(`.gitignore` already excludes it).

## 3. Rehearse, then launch
```
DRY_RUN=1 scripts/launch_website.sh     # shows every step, changes nothing, checks your settings
scripts/launch_website.sh               # the real launch
```
What the script does:
1. **Preflight**: tools, settings, and your keys (Supabase, OpenAI incl. model access, Stripe prices). It stops with a plain message if anything is wrong.
2. **Database and functions**: all migrations, all edge functions, all content.
3. **Secrets**: OpenAI key, caps, Stripe keys as Supabase secrets (values are never printed).
4. **Sign-in settings**: site address, redirects, optional captcha (needs `SUPABASE_ACCESS_TOKEN`; otherwise it prints what to set by hand).
5. **Website**: deploys to Cloudflare Pages and stores the website secrets.
6. **Admin**: tells you what to do next.
7. **Outside check**: tests the live site like a stranger would (no content visible, no login = no AI).

If the address printed by Cloudflare differs from `WEB_ORIGIN`, the script says so: correct `WEB_ORIGIN` in `launch/.env` and run it again.

## 4. Make yourself admin
1. Open your website address, choose "Create an account" and sign up with `ADMIN_EMAIL` (confirm the email if asked).
2. `DATABASE_URL=... scripts/make_admin.sh you@example.com`
3. Log in again. You now see the app without paying; the profile shows "Admin: full access, no limits".

## 5. Test it yourself (do not skip)
- [ ] Logged out, open the website: you only see the login page. Open `/index.html` and `/api/me`: no content.
- [ ] Sign up a second test account (another email). It lands on the **upgrade page** and cannot open the app.
- [ ] Admin: open Practice, answer an exercise: you get a score and feedback (this proves the AI service works).
- [ ] Admin: record a 20 second voice sample in the Voice analyzer, run the simulator for two messages, create the Charm Blueprint.
- [ ] With Stripe in test mode: pay with the test card `4242 4242 4242 4242` on the second account. Within seconds the app opens. Check the Supabase table `subscriptions`.
- [ ] Delete the second account from its profile page: you land on the login page.
- [ ] Phone: open the address, "Add to Home Screen", log in, use the microphone.
- [ ] Run `scripts/verify_deployment.sh` again whenever you change something (see its header for the settings).

## 6. AI costs and limits (read this)
| Who | AI requests per day | Voice analyses per day | Practice answers per day |
|---|---|---|---|
| no membership | cannot reach the AI | 1 per week | none |
| paying member | `MEMBER_DAILY_LIMIT` (default 300) | 20 | 20 |
| admin | unlimited | unlimited | unlimited |
- Every AI feature (coach, simulator message, blueprint, practice answer, voice analysis, website AI) counts against the same daily counter.
- Worst-case daily cost is roughly: members x cap x cost of one call. A call sends about 1,000 to 3,000 tokens in and a few hundred out; look up the current price of your model on OpenAI's pricing page and multiply. Start with a low cap (for example 100), watch the OpenAI usage page for a week, then raise it.
- **Always set the monthly spend limit in OpenAI.** It is your hard stop if anything unexpected happens.
- Change a cap: `supabase secrets set MEMBER_DAILY_LIMIT=150` (functions) and `AI_MEMBER_DAILY_LIMIT` in `cloudflare/members-site/wrangler.toml` (website), then redeploy the website.

## 7. If something goes wrong
| Symptom | Likely cause and fix |
|---|---|
| Preflight says the OpenAI key is rejected or out of quota | New key, or add billing credit at OpenAI. |
| Login works, then you are sent to the login page again | Site URL / redirect URLs in Supabase Authentication do not match `WEB_ORIGIN` exactly (https, no trailing slash). |
| Everyone lands on the upgrade page, also after paying | Stripe webhook not set up or wrong `STRIPE_WEBHOOK_SECRET`: check Stripe, Developers, Webhooks, and the `subscriptions` table. |
| You (admin) land on the upgrade page | `make_admin.sh` not run, or run for a different email than you log in with. |
| AI features say "unavailable" | `OPENAI_API_KEY` missing in the website secrets or in Supabase secrets, or the model name is not available to your key (`COACH_MODEL`, `AI_MODEL`). |
| AI says "limit" | The daily cap is used up (counter resets at midnight UTC). Admins are never capped. |
| No confirmation emails arrive | Supabase's built-in email is heavily limited. Set up your own SMTP (Authentication, SMTP) before inviting many people. |
| Sign up fails with a captcha message | Turnstile site key and secret must belong to the same widget, and both Supabase and the website must have the matching key. |

**Emergency brake**: `supabase secrets unset OPENAI_API_KEY` and delete the `OPENAI_API_KEY` secret of the Pages project (Cloudflare dashboard, Workers and Pages, your project, Settings, Variables and Secrets). All AI stops at once. To stop new signups: Supabase, Authentication, Sign In / Providers, disable "Allow new users to sign up".

## 8. Before you invite real members
- [ ] Custom domain on the Pages project; update `WEB_ORIGIN`, Supabase Site URL and redirect URLs; run the launch script again.
- [ ] Legal drafts in `docs/legal/` finished: replace every `[[PLACEHOLDER]]`, have a lawyer review, publish them (`scripts/check_legal.sh` and the preflight stop while placeholders remain; `ALLOW_LEGAL_DRAFT=1` only for rehearsals).
- [ ] Voice cleanup confirmed: recordings from failed analyses are deleted (privacy policy section 4).
- [ ] Privacy policy and terms published and linked (`PRIVACY_URL`, `TERMS_URL`); support email set.
- [ ] Own SMTP configured; Turnstile on; Stripe switched from test to live keys (new webhook secret and prices!).
- [ ] OpenAI monthly limit set; Supabase and Cloudflare two-factor login on.
- [ ] Later: mobile apps, see `docs/LAUNCH_CHECKLIST.md`.
