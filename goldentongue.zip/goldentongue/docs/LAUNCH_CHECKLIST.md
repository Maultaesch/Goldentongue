# Launch checklist: Cloudflare now, App Store and Google Play later

For the website with AI service use `docs/LAUNCH_WEBSITE.md` (one script). This list covers everything including the mobile apps. Work top to bottom. Tick each box only after you saw it work. `docs/AUDIT.md` lists what was already tested and what was not.

## 0. Before anything
- [ ] Change any password you ever pasted into a chat. Turn on two-factor login for Cloudflare, Supabase, Stripe, RevenueCat, Apple and Google accounts.
- [ ] Buy or choose the domain. Suggested: `api.<domain>` (gateway), `members.<domain>` (website), `www.<domain>` (public info page, optional).
- [ ] Publish a **privacy policy** and **terms of use** on public pages (get them reviewed by a lawyer; they must mention OpenAI as processor of texts and voice transcripts, Supabase, Stripe, Cloudflare, RevenueCat). You need both URLs for the stores.

## 1. Backend (Supabase)
- [ ] Create the project. Copy the project id, URL, anon key.
- [ ] `export SUPABASE_PROJECT_REF=... DATABASE_URL=...` then `scripts/deploy_backend.sh` (migrations 0001 to 0011, all functions, seeds).
- [ ] Secrets (`supabase secrets set NAME=value`): `OPENAI_API_KEY`, `STRIPE_SECRET_KEY`, `STRIPE_WEBHOOK_SECRET`, `STRIPE_PRICE_MONTHLY`, `STRIPE_PRICE_QUARTERLY`, `STRIPE_PRICE_YEARLY`, `APP_URL` (the members website address), `REVENUECAT_WEBHOOK_AUTH`; optional `COACH_MODEL`, `FREE_DAILY_LIMIT`, `EXERCISE_DAILY_LIMIT`.
- [ ] Authentication settings:
  - [ ] URL Configuration: Site URL = members website; redirect URLs = members website and `io.goldentongue://login-callback`.
  - [ ] Email: decide on "Confirm email" (recommended on). **Set up your own SMTP** (Resend, Postmark, SES): the built-in sender is limited to a few emails per hour.
  - [ ] Providers: Google and Apple (needed for the app buttons). Password rules: minimum length 8 or more, leaked password protection on.
  - [ ] Attack Protection: CAPTCHA on, provider Turnstile, paste the Turnstile secret.
- [ ] Run `supabase test db` once (the real pgTAP runner).
- [ ] Make yourself admin: sign up normally, then in the SQL editor `select public.grant_admin('you@example.com');`.

## 2. Payments
- [ ] Stripe (test mode first): three recurring prices (monthly 14.99, quarterly 34.99, yearly 99.99 USD); there is no free trial. Webhook endpoint `https://<project>.supabase.co/functions/v1/stripe-webhook`, events `customer.subscription.created`, `.updated`, `.deleted`, API version 2024-06-20. Enable Apple Pay and Google Pay in the Checkout settings.
- [ ] RevenueCat: add the iOS and Android apps, entitlement `premium`, offering with monthly, three-month and annual packages (product ids `gt_premium_monthly`, `gt_premium_quarterly`, `gt_premium_yearly`), webhook `https://<project>.supabase.co/functions/v1/revenuecat-webhook` with the Authorization value equal to `REVENUECAT_WEBHOOK_AUTH`.
- [ ] Test a full cycle in test mode: card 4242 4242 4242 4242 on the website, then check the `subscriptions` table, then log in and get in. Then cancel and check the lock-out.

## 3. Cloudflare
- [ ] `npx wrangler login`.
- [ ] Gateway: edit `cloudflare/worker/wrangler.toml` (UPSTREAM, ALLOWED_ORIGINS, `routes` for `api.<domain>`), `cd cloudflare/worker && npm install && npm test && npx wrangler deploy`.
- [ ] Members website: `cd cloudflare/members-site`, set `SUPABASE_URL`, `SUPABASE_ANON_KEY`, `OPENAI_API_KEY`, optional `TURNSTILE_SITE_KEY`, `PRIVACY_URL`, `TERMS_URL`, `SUPPORT_EMAIL`, then `scripts/deploy.sh`. Add the custom domain in the Pages project.
- [ ] Turnstile widget for the members hostname; the same site key goes into `TURNSTILE_SITE_KEY`.
- [ ] Dashboard: Security, WAF, Rate limiting rules for `/api/login`, `/api/signup` and `/api/ai`.
- [ ] Run `API_URL=... SUPABASE_ANON_KEY=... WEB_ORIGIN=... scripts/verify_deployment.sh` (add `TEST_EMAIL`, `TEST_PASSWORD`, `EXPECT_MEMBER`). Everything must say PASS.
- [ ] By hand on a phone: sign up, see the upgrade page, pay (test mode), get in, use the coach, record a voice sample, delete the test account; then log in as admin and confirm full access without paying.

## 4. Build the apps
- [ ] `flutter create --platforms=ios,android --org com.yourcompany .`, then `python3 scripts/setup_mobile.py` (permissions, deep link, app name).
- [ ] `flutter pub get`, `flutter analyze`, `flutter test`. Fix whatever the compiler reports (see `docs/AUDIT.md`: package APIs written from memory).
- [ ] App icon and launch screen (use your own artwork; `web_extras/icons` has a placeholder).
- [ ] Release builds with `--dart-define`: `SUPABASE_URL=https://api.<domain>`, `SUPABASE_ANON_KEY`, `REVENUECAT_IOS_KEY` / `REVENUECAT_ANDROID_KEY`, `TURNSTILE_SITE_KEY`, `TURNSTILE_BASE_URL=https://members.<domain>/`, `PRIVACY_URL`, `TERMS_URL`.

## 5. Apple App Store
- [ ] Apple Developer Program account; App ID with the **Sign in with Apple** capability (enable it in Xcode and in Supabase Auth, Apple provider).
- [ ] In App Store Connect: one subscription group with the three products (`gt_premium_monthly`, `gt_premium_quarterly`, `gt_premium_yearly`). No introductory offer or free trial. Link the app in RevenueCat.
- [ ] Test with sandbox testers (purchase, restore, cancel, expiry).
- [ ] Listing: description states price, period, auto-renewal and how to cancel; privacy policy URL; terms of use link (or the standard Apple EULA); support URL; screenshots; **age rating** answered honestly (dating and relationship advice, suggestive themes: expect 17+).
- [ ] **App Privacy** form: email address, user content (messages you type, voice transcripts), purchase information; processed by third parties (OpenAI, Supabase, Stripe, RevenueCat). Voice recordings are deleted after analysis; say so.
- [ ] **Review notes: give the reviewers a login.** The app shows nothing without a membership, so create a dedicated account, make it admin (`grant_admin`) and enter email and password in the review notes; explain that AI features call a cloud service and that the microphone is used for voice analysis.
- [ ] Do not mention or link to web payments or cheaper prices inside the iOS app (Apple rule 3.1.1). The app already pays only through the App Store.
- [ ] Risk to expect: Apple sometimes rejects apps that show nothing before payment as having too little free content. The reviewer account and a clear description help; if it happens, consider a small free preview in a later version.
- [ ] Account deletion is in the app (Profile, Delete account): mention it in the notes.

## 6. Google Play
- [ ] Play Console account; create the app; upload the signed app bundle (`flutter build appbundle`).
- [ ] Subscriptions with the same three product ids and a base plan each and no free trial offer; link in RevenueCat; test with license testers.
- [ ] **Data safety** form (data collected: email, user content, purchase history; shared with processors; encrypted in transit; deletion available). **Account deletion URL**: `https://members.<domain>/delete-account` (public page already included). Content rating questionnaire; target audience 18+; privacy policy URL.
- [ ] Provide the reviewer login in "App access" (same admin test account).

## 7. After launch
- [ ] Check Supabase logs and Cloudflare analytics daily in the first week; watch OpenAI spend (set a monthly limit in the OpenAI dashboard).
- [ ] Rotate keys on staff changes; keep `docs/AUDIT.md` updated when you change rules.
