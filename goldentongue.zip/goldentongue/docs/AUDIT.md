# Audit: what was checked, what was found, what is still unverified

## Where the product content lives
Nothing of the product content ships inside the free app download or in public web files: lines, openers, flirt techniques, challenges, exercises and the Deep Talk, Business and Speak Better cards are database rows that only members and admins can read (row level security, migrations 0009 and 0010). The website app file is served only after the member check. What stays in the app code is interface text (button labels, names of the six simulator characters, the rank names). The earlier standalone HTML previews with all content were removed from the download folder; the Claude preview page stays private to your account unless you share it.

## Required behaviour (as requested)
| Requirement | How it is enforced | Verified by |
|---|---|---|
| Account first | App router sends signed-out visitors to the login screen only. The website serves nothing but the login page. | `test/access_test.dart`, 43 website tests, `verify_deployment.sh` |
| Pay first | Signed-in accounts without a membership see only the paywall (app) or the upgrade page (website). The database itself hides all content from them (RLS), blocks XP and uploads, and AI functions answer 402. | 38 database checks on a real Postgres, 59 edge function tests under Deno, 43 website tests |
| Admin without paying | `public.admins` makes `is_premium` true, so the admin passes every gate, has no limits, and sees all content. Admin rights can only be granted in the SQL editor. | database checks (admin sees content, unlimited AI, unlimited voice, invisible admin list), handler tests |
| No client can cheat | Roles, scores, attempts and subscriptions are written only by security-definer functions or the service role. | database checks (writes denied), handler tests |

## Run during this audit (real tools, not just reading)
| What | Tool | Result |
|---|---|---|
| All 11 migrations and 5 seed files | real PostgreSQL with stand-ins for Supabase auth and storage | all apply cleanly |
| 42 database checks (premium rules, limits, fair-use caps, RLS, admin, pay first, section cards) | same database, small pgTAP-compatible shim | 42 of 42 pass |
| Edge functions: type check and 64 tests | Deno 2.9 | pass |
| Website functions: type check and 44 tests | Deno and Node | pass |
| API gateway: 14 tests | Node | pass |
| Mobile project script (permissions, deep link) | Python on sample files | pass, idempotent |
| Launch scripts: preflight (keys, settings, model, Stripe prices), dry-run launch, admin grant (including bad and malicious input), shellcheck | fake Supabase, OpenAI and Stripe services, real Postgres | 17 checks pass |
| Deployment check script | local mock of a correct and a leaking deployment | passes the first, flags the second |
| Flutter code: imports, routes, tables, RPCs and edge function names | static script | consistent (one unused import removed) |

## Problems found and fixed during the audit
1. Type errors in the simulator function (found by Deno): fixed.
2. The first migration required the `pgcrypto` extension, which is unnecessary on current Postgres: removed.
3. Any signed-in account could read lines, challenges and exercises directly through the API (content was only hidden in the app): migration `0009_paid_access.sql` now requires a membership for reading content, uploading audio and earning XP.
4. Free accounts could use the whole app: the app now shows only the paywall without a membership (router redirect), the website only the upgrade page.
5. No way to delete an account (required by the App Store and Google Play): added `delete-account` function, button in the app and on the website.
6. No links to a privacy policy and terms (required by both stores): `PRIVACY_URL` and `TERMS_URL` now show on login, paywall, profile and website.
7. Deep link and permission entries had to be edited by hand in the generated iOS and Android projects: `scripts/setup_mobile.py` does it.
8. Unused import in the paywall: removed.
9. Paying members had unlimited AI calls, so a bug or a stolen login could run up the AI bill: migration `0011_fair_use.sql` adds a daily cap per member (default 300 AI calls, 20 voice analyses, 20 practice answers); admins stay unlimited. Every AI function now counts against one shared daily counter (simulator, blueprint, practice and voice used to be uncounted).

## NOT verified here (needs your machine, accounts or devices)
- The Flutter app has never been compiled or run (no Flutter SDK here). Package versions in `pubspec.yaml` were not resolved. Packages written from memory and most likely to need an adjustment: `cloudflare_turnstile`, `purchases_flutter`, `record`, `speech_to_text`. Run `flutter pub get`, `flutter analyze`, `flutter test` first and fix what the compiler reports.
- Real Supabase (Auth, Storage, Edge runtime), Stripe, RevenueCat, Apple, Google and Cloudflare were not contacted. Payments, store purchases, sign in with Google and Apple, email confirmation, Turnstile and the OpenAI calls have not been tried end to end.
- The Flutter web build, the members website in a real browser, microphone and speech features on real phones.
- The Cloudflare rate limit binding syntax depends on your wrangler version.
- Real pgTAP and the Supabase CLI test runner were replaced by an equivalent shim; run `supabase test db` once.
